package cache
func ClearEntries() {}
