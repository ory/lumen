# Fixture Sources

All files in this directory are vendored from open-source projects for use as
E2E test fixtures. They are used solely for testing purposes.

## Go

- **prometheus/prometheus** (Apache 2.0) —
  https://github.com/prometheus/prometheus
- **prometheus/client_golang** (Apache 2.0) —
  https://github.com/prometheus/client_golang

## Java

- **spring-projects/spring-petclinic** (Apache 2.0) —
  https://github.com/spring-projects/spring-petclinic

## Dart

- **dart-lang/shelf** (BSD-3-Clause) — https://github.com/dart-lang/shelf
  (commit 4d99e49fa9275bfa348a88c0ce066bfcd335f763)

## PHP

- **laravel/framework** (MIT) — https://github.com/laravel/framework

## JavaScript

- **expressjs/express** (MIT) — https://github.com/expressjs/express
- **fastify/fastify** (MIT) — https://github.com/fastify/fastify
- **nodejs/node** (MIT) — https://github.com/nodejs/node

## TypeScript

- **microsoft/vscode** (MIT) — https://github.com/microsoft/vscode

## Ruby

- **rails/rails** (MIT) — https://github.com/rails/rails
- **sinatra/sinatra** (MIT) — https://github.com/sinatra/sinatra

## Python

- **pallets/flask** (BSD-3-Clause) — https://github.com/pallets/flask
- **django/django** (BSD-3-Clause) — https://github.com/django/django

## Rust

- **BurntSushi/ripgrep** (MIT/Unlicense) — https://github.com/BurntSushi/ripgrep
- **tokio-rs/tokio** (MIT) — https://github.com/tokio-rs/tokio

## YAML

- **kubernetes/website** (Apache 2.0) — https://github.com/kubernetes/website
  (example manifests)
- **docker/awesome-compose** (Apache 2.0) —
  https://github.com/docker/awesome-compose
- **prometheus-community/helm-charts** (Apache 2.0) —
  https://github.com/prometheus-community/helm-charts
- Various GH Actions workflow files from the above projects (ci.yml, tests.yml,
  etc.)
- Hand-authored standard Kubernetes manifest examples (Deployment, Service,
  StatefulSet, Ingress, ConfigMap)

## Markdown

- **rust-lang/book** (MIT/Apache 2.0) — https://github.com/rust-lang/book

## Swift

- **vapor/vapor** (MIT) — https://github.com/vapor/vapor
  (commit a8db2dbda8b3cdc8a61bd35128590bd296e85563)

## Svelte

- **huggingface/chat-ui** (Apache 2.0) — https://github.com/huggingface/chat-ui
  (commit c0cfbdf)

## JSON

- **microsoft/TypeScript** (Apache 2.0) —
  https://github.com/microsoft/TypeScript
- **microsoft/vscode** (MIT) — https://github.com/microsoft/vscode
- Various package.json files from the above projects (expressjs/express,
  facebook/react, eslint/eslint, prettier/prettier)
